# eyeglobal-cfs-integration v28
Complete CFS Integration app for ERPNext v15. Includes Vehicle Units, Sales Rebates & Payouts, Settings, scheduled monthly payouts, tests and CI workflow.
