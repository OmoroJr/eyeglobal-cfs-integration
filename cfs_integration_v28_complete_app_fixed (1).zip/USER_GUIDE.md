See doctypes and README. Install with bench, load fixtures, set CFS Settings, configure accounts before payouts.
