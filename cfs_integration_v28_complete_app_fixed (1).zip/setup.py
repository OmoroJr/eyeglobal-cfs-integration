from setuptools import setup, find_packages
setup(name='cfs_integration', version='0.8.0', packages=find_packages(), include_package_data=True)
